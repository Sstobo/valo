<?php
/**
 * The template for displaying all pages.
 * Template Name: services_partnership
 * @package RED_Starter_Theme
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<section class=
	
		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
