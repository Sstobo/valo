<div class="signup-wrapper">
						<div class="signup-container">
					<h1 id="form-title"> Sign Up for the Latest VALO News </h1>
					<?php echo do_shortcode('[contact-form-7 id="4" title="Contact form 1"]');?>
				</div>
			</div>

		<div class="contact-footer">
			<img alt="footer logo" src="<?php echo get_template_directory_uri() . '/assets/Logo SVG/VALO white logo-01.png'?>" id="contact-logo"/>
			<div class="copy-top">
				<p id="contact-copy"> &copy VALO Smart City 2018. All Rights Reserved.</p> 
				<!-- <div class="fix"> 
					<i class="fa fa-long-arrow-up" aria-hidden="true"></i>
				</div> -->
					
			</div>

			  
		</div>